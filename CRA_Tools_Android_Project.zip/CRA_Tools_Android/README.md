# CRA Tools Android

Android app wrapper for the CRA Tools dashboard.

Included:
- CRA Reassessment Image Analyzer
- CRA Reassessment Change Analyzer
- T1 Adjustment Impact Simulator

## Build in Android Studio
1. Open this folder in Android Studio.
2. Let Gradle sync; install Android SDK 35 if requested.
3. Build > Build App Bundle(s) / APK(s) > Build APK(s).
4. Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Automatic build on GitHub
A workflow is included at `.github/workflows/build-apk.yml`. Push this project to GitHub and run `Build Android APK`; download the `CRA-Tools-debug-apk` artifact.

## Notes
- Most tools are bundled and work offline.
- Image Analyzer OCR currently loads Tesseract.js from an HTTPS CDN, so OCR requires internet access.
- App name: CRA Tools
- Package: com.ionut.cratools
- Minimum Android: 8.0 / API 26
