package com.ionut.cratools;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class NativeSmokeTest {
    @Test public void bundledOcrReadsFictionalReturnAndJoinsColumns() throws Exception {
        Bitmap bitmap=Bitmap.createBitmap(1600,900,Bitmap.Config.ARGB_8888);
        Canvas canvas=new Canvas(bitmap);canvas.drawColor(Color.WHITE);
        Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);paint.setColor(Color.BLACK);paint.setTextSize(44);
        String[] labels={"Line 15000","Line 26000","Line 31800"};
        String[] values={"$50,000.00","$48,000.00","$1,000.00"};
        for(int i=0;i<labels.length;i++){canvas.drawText(labels[i],70,150+i*150,paint);canvas.drawText(values[i],700,150+i*150,paint);}
        TextRecognizer recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        try {
            Text result=Tasks.await(recognizer.process(InputImage.fromBitmap(bitmap,0)),45,TimeUnit.SECONDS);
            String rows=MainActivity.spatialRows(result);
            assertTrue(rows.contains("15000"));assertTrue(rows.contains("26000"));assertTrue(rows.contains("31800"));
            assertTrue(rows.matches("(?s).*15000[^\\n]*50,000\\.00.*"));assertTrue(rows.matches("(?s).*26000[^\\n]*48,000\\.00.*"));
        } finally {recognizer.close();bitmap.recycle();}
    }
    @Test public void onlyOfficialHttpsReferenceHostsAreAllowed() throws Exception {
        for(String address:OfficialSources.URLS.values())assertTrue(OfficialSources.allowed(new URL(address)));
        assertFalse(OfficialSources.allowed(new URL("http://www.canada.ca/")));
        assertFalse(OfficialSources.allowed(new URL("https://www.canada.ca.example.com/")));
        assertFalse(OfficialSources.allowed(new URL("https://example.com/")));
    }
}
