(function(root) {
"use strict";
const sources={
 t1:{title:"CRA · 2025 federal T1",url:"https://www.canada.ca/content/dam/cra-arc/formspubs/pbg/5000-r/5000-r-25e.txt",hash:"261c9da60362ccd58e32e3b28ab93860a7632efbefdee017716a597557faa089"},
 quebec:{title:"CRA · 2025 Quebec federal T1",url:"https://www.canada.ca/content/dam/cra-arc/formspubs/pbg/5005-r/5005-r-25e.txt",hash:"ee96722363745b87d1fb68eb7f2feae51433b8c0d0e665fbd15b3ff71841b96c"},
 topup:{title:"CRA · Top-up tax credit",url:"https://www.canada.ca/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/tax-return/completing-a-tax-return/deductions-credits-expenses/line-34990-top-up-tax-credit.html"},
 abatement:{title:"CRA · Quebec abatement",url:"https://www.canada.ca/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/tax-return/completing-a-tax-return/deductions-credits-expenses/line-44000-refundable-quebec-abatement.html"},
 act:{title:"Justice Canada · Income Tax Act",url:"https://laws-lois.justice.gc.ca/eng/acts/I-3.3/"},
 regulations:{title:"Justice Canada · Income Tax Regulations",url:"https://laws-lois.justice.gc.ca/eng/regulations/C.R.C.,_c._945/"},
 current:{title:"CRA · Current-year tax rates",url:"https://www.canada.ca/en/revenue-agency/services/tax/individuals/tax-rates-brackets/current-year.html"},
 news:{title:"CRA · Latest return changes",url:"https://www.canada.ca/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/tax-return/completing-a-tax-return/whats-new.html"}
};
function check(records,year,province,now=Date.now()) {
const needed=["t1","topup","act","regulations",...(province==="QC"?["quebec","abatement"]:[])],reasons=[];
if(Number(year)!==2025)reasons.push("No validated calculation rules for "+year+". The official sources remain available for review.");
for(const id of needed) {
const r=records[id],s=sources[id];
if(!r?.ok || !Number.isFinite(r.checkedAt) || r.checkedAt>now+60000 || now-r.checkedAt>86400000) {reasons.push(s.title+": current online verification needed.");continue;}
if(s.hash && r.hash!==s.hash)reasons.push(s.title+": the official form changed. Calculation rules require review.");
if((id==="act" || id==="regulations") && (r.amended!=="2026-06-18" || !r.currentTo || r.currentTo<"2026-09-30"))reasons.push(s.title+": legislation changed or its currency could not be established. Rules require review.");
if(id==="topup" && !r.signals)reasons.push(s.title+": year-specific rate or threshold changed. Rules require review.");
}
return {verified:reasons.length===0,reasons};
}
const api={sources,check};
if(typeof module!=="undefined" && module.exports)module.exports=api;else root.CRAOfficial=api;
})(typeof globalThis!=="undefined"?globalThis:this);
