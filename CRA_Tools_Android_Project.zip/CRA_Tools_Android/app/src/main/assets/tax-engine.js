/* Pure, offline analysis. Money is integer CAD cents; a missing value is never zero. */
(function(root) {
  "use strict";
  const L = typeof module !== "undefined" && module.exports ? require("./line-catalog.js") : root.CRALines;
  const info = line => line==="federal_gross"?{n:"Federal tax on taxable income before credits",g:"federal_gross"}:L[line] || {n:"Unmapped T1 line",g:"unknown"};
  const validLine = line => /^[1-9]\d{4}$/.test(String(line));
  const round = n => Math.sign(n) * Math.round(Math.abs(n) + 1e-8);
  const rate = (cents, numerator, denominator=1000) => round(cents*numerator/denominator);
  function parseMoney(input) {
    if (input === null || input === undefined) return null;
    let s=String(input).trim().replace(/\u2212/g,"-").replace(/[\u00a0\u202f]/g," ");
    if (!s) return null;
    let negative=false;
    if (/^\(.*\)$/.test(s)) {negative=true;s=s.slice(1,-1).trim();}
    if (/^-/.test(s)) {if(negative)return null;negative=true;s=s.slice(1).trim();}
    s=s.replace(/^(?:CAD\s*|\$\s*)/i,"").replace(/\s*(?:CAD|\$)$/i,"").trim();
    if (!s || /[^\d., ]/.test(s)) return null;
    let decimal="";
    if (s.includes(",") && s.includes(".")) decimal=s.lastIndexOf(",")>s.lastIndexOf(".")?",":".";
    else if (/[.,]\d{1,2}$/.test(s)) decimal=s.match(/[.,](?=\d{1,2}$)/)[0];
    let whole=s,fraction="";
    if(decimal) {const at=s.lastIndexOf(decimal);whole=s.slice(0,at);fraction=s.slice(at+1);if(!/^\d{1,2}$/.test(fraction))return null;}
    const grouping=whole.match(/[., ]/g);
    if(grouping) {
      if(new Set(grouping).size!==1 || grouping[0]===decimal) return null;
      const sep=grouping[0];
      if(!new RegExp("^\\d{1,3}(?:\\"+sep+"\\d{3})+$").test(whole)) return null;
      whole=whole.split(sep).join("");
    }
    if(!/^\d+$/.test(whole))return null;
    const cents=Number(whole)*100+Number(fraction.padEnd(2,"0")||0);
    if(!Number.isSafeInteger(cents) || cents>999999999999) return null;
    return negative?-cents:cents;
  }
  const money = cents => cents===null || cents===undefined || !Number.isSafeInteger(cents) ? "—" :
    (cents<0?"−$":"$")+(Math.abs(cents)/100).toLocaleString("en-CA",{minimumFractionDigits:2,maximumFractionDigits:2});
  const amountText = cents => cents===null || cents===undefined ? "" : (cents/100).toFixed(2);
  const value = record => record && record.confirmed===true && Number.isSafeInteger(record.amount) ? record.amount : null;
  const get = (doc,line) => value(doc[line]);
  const issue = (code,message,lines=[],side=null) => ({code,message,lines,side});
  const core = ["15000","23600","26000","35000","42000","43500","48200"];
  function parseOCR(text,source="OCR") {
    const found={},warnings=[];
    const rows=String(text).replace(/\r/g,"").split("\n");
    const linePattern=/(?:\b(?:line|ligne)\s*[:#]?\s*([1-9][\dOoIl]{4})\b)|\b([1-9]\d{4})\b/ig;
    function normalized(s) {return s.replace(/[Oo]/g,"0").replace(/[Il]/g,"1");}
    rows.forEach((row,index)=>{
      const matches=[...row.matchAll(linePattern)];
      const explicit=matches.filter(m=>m[1]);
      const selected=explicit.length?explicit:matches.filter(m=>L[m[2]]);
      if(!selected.length)return;
      // Multiple explicit line labels can be split safely; other multi-column rows require review.
      const starts=explicit.length?explicit:[selected[0]];
      starts.forEach((m,part)=>{
        const line=normalized(m[1]||m[2]);
        const end=starts[part+1] ? starts[part+1].index : row.length;
        const tail=row.slice(m.index+m[0].length,end);
        let scan=tail.trim().replace(/^[|:=]\s*/,"");
        // The existing parser's adjacent-row recovery is restricted to an amount-only next row.
        let adjacent=false;
        if(!scan && index+1<rows.length && parseMoney(rows[index+1])!==null) {scan=rows[index+1].trim();adjacent=true;}
        const amounts=[...scan.matchAll(/(?:\(?[-−]?\s*\$?\s*\d[\d.,\u00a0\u202f ]*\)?)/g)]
          .map(x=>({raw:x[0].trim(),amount:parseMoney(x[0])})).filter(x=>x.raw);
        const clean=amounts.filter(x=>x.amount!==null);
        let amount=clean.length===1 && amounts.length===1 ? clean[0].amount : null;
        const multiple=!explicit.length && selected.length>1 && selected[1].index>m.index;
        if(multiple && clean.length!==1) amount=null;
        const candidate={amount,confirmed:false,source,description:row.slice(0,m.index).trim()||info(line).n,
          evidence:row.trim().slice(0,500),alternatives:clean.map(a=>a.amount),uncertain:true,
          reason:amount===null?"Ambiguous or missing amount. Enter the amount from the image.":adjacent?"Amount found on the next row. Check the association.":"Check line and amount against the image."};
        if(found[line]) {
          found[line].alternatives=[...new Set([...found[line].alternatives,...candidate.alternatives])];
          found[line].reason="Repeated line on this page. Check all occurrences.";
          if(found[line].amount!==candidate.amount)found[line].amount=null;
        } else found[line]=candidate;
      });
    });
    if(!Object.keys(found).length)warnings.push("No line/amount pair found. Photograph the line labels and amount columns together.");
    return {lines:found,warnings};
  }
  function mergeOCR(existing,incoming) {
    const merged={...existing};
    for(const [line,row] of Object.entries(incoming)) {
      const old=merged[line];
      if(!old) {merged[line]={...row};continue;}
      const alternatives=[...new Set([old.amount,row.amount,...(old.alternatives||[]),...(row.alternatives||[])].filter(x=>x!==null))];
      // Never silently replace a reviewed value, even when another page agrees.
      merged[line]={...old,confirmed:false,alternatives,source:old.source+"; "+row.source,
        amount:old.amount===row.amount?old.amount:null,
        reason:old.amount===row.amount?"Repeated across pages; confirm once.":"Conflicting pages. Choose the correct value manually.",
        evidence:(old.evidence||"")+"\n"+(row.evidence||"")};
    }
    return merged;
  }
  const explanation = line => {
    const g=info(line).g;
    if(g==="nrtc" || g.startsWith("nrtc_"))return "A federal non-refundable credit may reduce federal tax, limited by tax otherwise payable. It does not reduce taxable income. Eligibility and provincial treatment require separate verification.";
    if(g.includes("deduction"))return "A revised deduction may affect net income and/or taxable income. Related worksheets, limits and income-tested items can also change.";
    if(["income","total_income","net_income","taxable_income","net_stage"].includes(g))return "An income revision may flow to tax calculations and income-tested credits or benefits. The documents alone do not establish why CRA changed it.";
    if(["credit","total_credits"].includes(g))return "An accepted payment or credit change can affect refund or balance through total credits. It is not a change to taxable income.";
    if(line==="42800")return "This is the provincial/territorial amount shown on the federal T1. Its underlying provincial calculation is separate.";
    return "This is an observed document difference. The reassessment notice or supporting worksheet is needed to establish its cause.";
  };
  function outcome(doc) {
    const payable=get(doc,"43500"),credits=get(doc,"48200");
    if(payable===null || credits===null)return null;
    return credits-payable;
  }
  function checkOutcome(doc,side) {
    const out=outcome(doc),problems=[];
    const refund=get(doc,"48400"),owing=get(doc,"48500");
    if(refund!==null && owing!==null && refund>0 && owing>0)
      problems.push(issue("inconsistent","Refund and balance owing are both positive.",["48400","48500"],side));
    if(out!==null && ((refund!==null && refund!==Math.max(out,0)) || (owing!==null && owing!==Math.max(-out,0))))
      problems.push(issue("inconsistent","Final lines disagree with 48200 minus 43500. Review these figures; no final result is available.",["43500","48200","48400","48500"],side));
    return problems;
  }
  function compare(before,after,context={}) {
    const rows=[],issues=[],missing={before:[],after:[]};
    const all=[...new Set([...core,...Object.keys(before),...Object.keys(after)])].sort();
    for(const line of all) {
      const a=get(before,line),b=get(after,line);
      if(a===null)missing.before.push(line);
      if(b===null)missing.after.push(line);
      if(a===null || b===null)continue;
      rows.push({line,description:before[line]?.description||after[line]?.description||info(line).n,
        before:a,after:b,change:b-a,type:"observed change",explanation:explanation(line)});
    }
    for(const side of ["before","after"])if(missing[side].length)
      issues.push(issue("missing","Photograph or confirm "+side+" lines: "+missing[side].join(", ")+".",missing[side],side));
    const consistency=[...checkOutcome(before,"before"),...checkOutcome(after,"after")];
    issues.push(...consistency);
    if(!context.sameContext)issues.push(issue("context","Confirm both documents concern the same tax year, taxpayer and jurisdiction."));
    const old=outcome(before),next=outcome(after);
    const final=context.sameContext && !consistency.length && old!==null && next!==null ?
      {before:old,after:next,change:next-old,type:"calculated consequence"} : null;
    const impacts=["26000","35000","42000","42800","43500","48200"].map(line=>rows.find(r=>r.line===line)||{line,before:null,after:null,change:null});
    return {rows,issues,missing,impacts,final,
      possibleExplanation:"Possible explanations describe relationships, not CRA's confirmed reason. Check the reassessment notice or relevant schedule. Return totals exclude account interest, penalties, offsets and payments after assessment."};
  }
  // Validated 2025 federal rates only. Other years remain explicitly unmapped.
  function federalGross(taxable,year) {
    if(Number(year)!==2025 || !Number.isSafeInteger(taxable) || taxable<0)return null;
    const brackets=[[5737500,0,145,0],[11475000,5737500,205,831938],[17788200,11475000,260,2008125],[25341400,17788200,290,3649557],[Infinity,25341400,330,5839985]];
    const [,low,r,base]=brackets.find(([high])=>taxable<=high);
    return base+rate(taxable-low,r);
  }
  const income=new Set(["10100","10400","12100","12900","13000"]);
  const deductions=new Set(["20700","20800","20805","21200","21400","21500","21900","22000","22100","22900","23200"]);
  const taxableDeductions=new Set(["24400","24900","25100","25200","25300","25400","25500","25600"]);
  const nrtc=new Set(["30000","30100","30300","30400","30800","31200","31220","31240","31260","31270","31285","31300","31600","31800","31900","32300","32400","32600"]);
  const payments=new Set(["43700","47600"]);
  const payableLeaves=new Set(["42000","42100","42120","42200","42800"]);
  const downstream = line => {
    if(income.has(line))return ["15000","23300","23400","23500","23600","25700","26000","33500","33800","35000","40400","42900","42000","43500","44000","48200","48400","48500"];
    if(deductions.has(line))return ["23300","23400","23500","23600","25700","26000","33500","35000","40400","42900","42000","43500","44000","48200","48400","48500"];
    if(taxableDeductions.has(line))return ["25700","26000","40400","42900","42000","43500","44000","48200","48400","48500"];
    if(nrtc.has(line))return ["33500","33800","35000","42900","42000","43500","44000","48200","48400","48500"];
    if(payments.has(line))return ["48200","48400","48500"];
    if(payableLeaves.has(line))return ["43500","48400","48500"];
    if(line==="43500" || line==="48200")return ["48400","48500"];
    return [];
  };
  function simulate(doc,edits,context={}) {
    const issues=[],rows=[],projected={},missing=new Set();
    let blocked=false;
    function stop(message,lines=[]) {blocked=true;issues.push(issue("dependency not yet mapped",message,lines));}
    function need(line) {
      const v=get(doc,line);
      if(v===null) {missing.add(line);blocked=true;}
      return v;
    }
    function add(line,after,why,type="calculated consequence") {
      const before=get(doc,line);
      if(after===null || !Number.isSafeInteger(after))return;
      projected[line]=after;
      rows.push({line,description:info(line).n,before,after,change:before===null?null:after-before,type,explanation:why});
    }
    if(!context.province)stop("Select the jurisdiction of the federal T1.");
    if(context.province==="NONRES")stop("Non-resident and special-return rules are not yet mapped.");
    if(!context.officialVerified)stop("Verify the current official CRA sources and legislation online before calculating. Source changes require rule review.");
    if(Number(context.year)!==2025)stop("Federal rules for tax year "+context.year+" are not yet mapped. Confirmed original and requested values can still be reviewed.");
    if(!context.scopeConfirmed)stop("Confirm the simulation scope: entered amounts are allowable claims and other linked amounts have been reviewed. Special returns require separate rules.");
    const active=[];
    for(const edit of edits) {
      if(!validLine(edit.line) || !Number.isSafeInteger(edit.amount)) {stop("Enter a five-digit line and a complete valid amount.");continue;}
      if(active.some(e=>e.line===edit.line)) {stop("Duplicate adjustment for line "+edit.line+".",[edit.line]);continue;}
      const before=need(edit.line);
      if(edit.amount<0 && !income.has(edit.line)) {stop("A negative amount is unsupported for line "+edit.line+".",[edit.line]);continue;}
      add(edit.line,edit.amount,"Requested input. Claim eligibility is not established by this simulation.","requested adjustment");
      if(before!==null && before!==edit.amount)active.push({...edit,delta:edit.amount-before});
    }
    if(!active.length)stop("Add at least one adjustment with a confirmed original amount.");
    const conflict=active.some(e=>active.some(other=>other!==e && downstream(e.line).includes(other.line)));
    if(conflict)stop("A detail line and one of its totals were both edited. Remove the overlapping total to prevent double counting.");
    if(blocked || conflict) return finish();
    let incomeDelta=0,deductionDelta=0,taxableDeductionDelta=0,nrtcDelta=0,paymentDelta=0,taxDelta=0;
    let creditsDirect=null,payableDirect=null,hasIncome=false,hasNrtc=false,hasTax=false;
    for(const e of active) {
      if(income.has(e.line)) {incomeDelta+=e.delta;hasIncome=true;}
      else if(deductions.has(e.line)) {deductionDelta+=e.delta;hasIncome=true;}
      else if(taxableDeductions.has(e.line)) {taxableDeductionDelta+=e.delta;hasIncome=true;}
      else if(nrtc.has(e.line)) {nrtcDelta+=e.delta;hasNrtc=true;}
      else if(payments.has(e.line))paymentDelta+=e.delta;
      else if(payableLeaves.has(e.line)) {taxDelta+=e.delta;hasTax=true;}
      else if(e.line==="48200")creditsDirect=e.amount;
      else if(e.line==="43500") {payableDirect=e.amount;hasTax=true;}
      else stop("Dependency not yet mapped for line "+e.line+". Only the requested change can be confirmed.",[e.line]);
    }
    if(hasIncome) {
      if(incomeDelta) {const total=need("15000");if(total!==null)add("15000",total+incomeDelta,"Confirmed total income plus the entered income changes.");}
      let net=null;
      if(incomeDelta || deductionDelta) {
        const totalDeductions=need("23300"),total=need("15000"),oldNet=need("23600"),repayment=need("23500");
        if(totalDeductions!==null && totalDeductions+deductionDelta<0)stop("The requested changes would make total deductions negative. Review the original component and total amounts.",["23300"]);
        else if(totalDeductions!==null)add("23300",totalDeductions+deductionDelta,"Total deductions plus entered deduction changes.");
        if(total!==null && totalDeductions!==null && totalDeductions+deductionDelta>=0) {
          const beforeAdjustments=total+incomeDelta-totalDeductions-deductionDelta;
          add("23400",beforeAdjustments,"Income less deductions, before benefit repayment.");
          // Repayment rules cannot be assumed from the old value. Explicit zero benefit lines are required.
          const benefits=["11300","11900","14600"].map(need);
          if(benefits.some(v=>v!==0) || repayment!==0)stop("Social-benefit repayment requires a separate worksheet. Net income cannot be propagated.",["11300","11900","14600","23500"]);
          else if(oldNet!==null && oldNet!==Math.max(0,total-totalDeductions))stop("Original net income does not reconcile with income, deductions and zero repayment.",["15000","23300","23500","23600"]);
          else {net=Math.max(0,beforeAdjustments);add("23600",net,"Confirmed zero benefit income and zero repayment; net income is floored at zero.");}
        }
      } else net=need("23600");
      const deductionTotal=need("25700");
      if(deductionTotal!==null && deductionTotal+taxableDeductionDelta<0)stop("Requested taxable-income deductions would make their total negative.",["25700"]);
      if(taxableDeductionDelta && deductionTotal!==null)add("25700",deductionTotal+taxableDeductionDelta,"Revised total deductions from net income.");
      if(net!==null && deductionTotal!==null && deductionTotal+taxableDeductionDelta>=0) {
        const taxable=Math.max(0,net-deductionTotal-taxableDeductionDelta);
        add("26000",taxable,"Net income less the confirmed total of taxable-income deductions, floored at zero.");
        add("federal_gross",federalGross(taxable,context.year),"2025 federal bracket calculation before credits; this is not net federal tax.");
      }
      stop("Income-tested credits, benefit calculations, minimum tax and provincial dependencies are not yet mapped. No final refund or balance is estimated for this income change.");
    }
    if(hasNrtc) {
      const base=need("33500"),converted=need("33800"),donations=need("34900"),topup=need("34990"),total=need("35000");
      if(base!==null && base+nrtcDelta>=0)add("33500",base+nrtcDelta,"Federal credit base plus the entered allowable claim changes.");
      if(base!==null && base+nrtcDelta<0)stop("Federal credit base would be negative.",["33500"]);
      // Top-up worksheet also incorporates other credit items. Keep the mapped case deliberately narrow.
      if(donations!==null && donations!==0)stop("Donation and top-up worksheet interactions are not yet mapped.",["34900","34990"]);
      if(topup!==null && topup!==0)stop("A nonzero top-up credit requires the complete worksheet.",["34990"]);
      if(base!==null && (base>5737500 || base+nrtcDelta>5737500))stop("The 2025 top-up threshold is crossed. The top-up worksheet is not yet mapped.",["33500","34990"]);
      if(base!==null && converted!==null && converted!==rate(base,145))stop("The original credit conversion does not reconcile. Check 33500 and 33800.",["33500","33800"]);
      if(total!==null && converted!==null && donations!==null && topup!==null && total!==converted+donations+topup)stop("Original credit totals do not reconcile.",["33800","34900","34990","35000"]);
      if(!blocked && base!==null) {
        const newConverted=rate(base+nrtcDelta,145),newTotal=newConverted+donations+topup;
        add("33800",newConverted,"2025 credit rate: 14.5% of the revised federal credit base.");
        add("35000",newTotal,"Converted credits plus confirmed donations credit and top-up.");
        const gross=need("40400"),dividend=need("40425"),carryover=need("40427"),oldBasic=need("42900");
        const exclusions=["40424","40500","41000","41200","41400","41500","41800"].map(need);
        const oldFederal=need("42000");
        if(exclusions.some(v=>v!==0) || dividend!==0 || carryover!==0 || (oldFederal!==null && oldBasic!==null && oldFederal!==oldBasic))
          stop("Additional federal tax items or minimum-tax interactions require separate rules. Net federal tax is not estimated.",["40424","40425","40427","40500","41000","41200","41400","41500","41800","42000","42900"]);
        if(gross!==null && oldBasic!==null && total!==null && oldBasic!==Math.max(0,gross-total))
          stop("Original basic federal tax does not reconcile.",["40400","35000","42900"]);
        if(!blocked && gross!==null) {
          const basic=Math.max(0,gross-newTotal);
          add("42900",basic,"Federal tax before credits less revised credits, limited to zero.");
          add("42000",basic,"Simple full-year federal case; other federal tax items confirmed zero.");
          taxDelta+=basic-oldFederal;hasTax=true;
          if(context.province==="QC") {
            const abatement=need("44000");
            if(abatement!==null && abatement!==rate(oldBasic,165))stop("Original Quebec abatement does not match the mapped full-year case. Review the worksheet.",["44000","42900"]);
            if(abatement!==null && !blocked) {const revised=rate(basic,165);add("44000",revised,"Quebec federal abatement: 16.5% of basic federal tax in the confirmed full-year simple case.");paymentDelta+=revised-abatement;}
          } else {
            // User must supply the revised provincial T1 amount; never carry the old one silently.
            if(!edits.some(e=>e.line==="42800" && Number.isSafeInteger(e.amount) && get(doc,"42800")!==null))stop("Provincial rules are not mapped. Enter a separately verified new line 42800 (including an explicit unchanged value) before calculating a federal-T1 final result.",["42800"]);
          }
        }
      }
    }
    if(hasTax && !hasNrtc && context.province==="QC" && active.some(e=>e.line==="42000" || e.line==="43500"))
      stop("A direct federal-tax edit may affect Quebec abatement. Supply a fully reconciled calculation; this dependency is not yet mapped.",["42900","44000"]);
    const oldPayable=need("43500"),oldCredits=need("48200");
    const consistency=checkOutcome(doc,"original");
    if(consistency.length) {issues.push(...consistency);blocked=true;}
    if(!blocked && oldPayable!==null && oldCredits!==null) {
      const payable=payableDirect===null?oldPayable+taxDelta:payableDirect;
      const credits=creditsDirect===null?oldCredits+paymentDelta:creditsDirect;
      if(payable<0 || credits<0)stop("Totals cannot be negative. Review the requested amounts.",["43500","48200"]);
      else {
        if(payableDirect===null)add("43500",payable,"Original total payable plus supported changes to its components.");
        if(creditsDirect===null)add("48200",credits,"Original total credits plus supported changes to its components.");
        const out=credits-payable;
        add("48400",Math.max(out,0),"Positive credits minus payable: refund shown on the federal T1.");
        add("48500",Math.max(-out,0),"Positive payable minus credits: balance shown on the federal T1.");
      }
    }
    return finish();
    function finish() {
      if(missing.size)issues.push(issue("missing","Photograph or confirm original lines: "+[...missing].join(", ")+". Missing amounts are never treated as zero.",[...missing],"original"));
      const old=outcome(doc);
      const final=!blocked && projected["43500"]!==undefined && projected["48200"]!==undefined ?
        {before:old,after:projected["48200"]-projected["43500"],change:projected["48200"]-projected["43500"]-old,type:"calculated consequence"} : null;
      return {rows,issues,missing:[...missing],final,province:context.province==="QC" ?
        "Federal T1 result only. Quebec provincial income tax is separate and has not been simulated." :
        "Provincial tax is not calculated. Any entered line 42800 is a separately supplied amount.",
        note:"Conditional estimate for the entered allowable claims and reviewed scope. Account interest, penalties, offsets and post-assessment payments are excluded."};
    }
  }
  const api={info,validLine,parseMoney,money,amountText,value,get,parseOCR,mergeOCR,compare,simulate,federalGross,downstream,rate};
  if(typeof module!=="undefined" && module.exports)module.exports=api;else root.CRAEngine=api;
})(typeof globalThis!=="undefined"?globalThis:this);
