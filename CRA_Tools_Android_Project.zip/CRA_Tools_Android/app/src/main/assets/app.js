(function() {
"use strict";
const E=window.CRAEngine, O=window.CRAOfficial, sourceRecords={}, main=document.getElementById("main");
const state={mode:"home",docs:{before:{},after:{}},photos:{before:[],after:[]},edits:[],year:2025,province:"QC",scope:false,same:false,busy:false,epoch:0};
let dark=matchMedia("(prefers-color-scheme: dark)").matches,themeChosen=false,toastTimer;
const icons={
compare:'<path d="M8 3H3v18h13V8L11 3H8"/><path d="M11 3v5h5M7 12h5M7 16h5M17 3h4v15h-3"/>',
simulate:'<path d="M4 7h16M4 17h16M8 4v6M16 14v6"/><circle cx="8" cy="7" r="3"/><circle cx="16" cy="17" r="3"/>',
camera:'<path d="M4 6h4l2-3h4l2 3h4a1 1 0 0 1 1 1v13H3V7a1 1 0 0 1 1-1Z"/><circle cx="12" cy="13" r="4"/>',
upload:'<path d="M12 16V3M7 8l5-5 5 5M4 16v5h16v-5"/>',
arrow:'<path d="M4 12h16M14 6l6 6-6 6"/>',
back:'<path d="M20 12H4M10 6l-6 6 6 6"/>',
shield:'<path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6Z"/><path d="m8 12 3 3 5-6"/>',
moon:'<path d="M20 14a8 8 0 0 1-10-10 8 8 0 1 0 10 10Z"/>',
sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5 19 19M5 19l1.5-1.5M17.5 6.5 19 5"/>',
plus:'<path d="M12 4v16M4 12h16"/>',
document:'<path d="M5 3h9l5 5v13H5Z"/><path d="M14 3v5h5M9 12h6M9 16h6"/>'
};
const icon=name=>'<svg viewBox="0 0 24 24" aria-hidden="true">'+(icons[name]||icons.document)+'</svg>';
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const button=(label,action,kind="",extra="")=>'<button class="button '+kind+'" data-action="'+action+'" '+extra+'>'+label+'</button>';
const chip=(label,kind="")=>'<span class="chip '+kind+'">'+esc(label)+'</span>';
function toast(message) {const el=document.getElementById("toast");el.textContent=message;el.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove("show"),5000);}
function setTheme(value) {dark=value;document.documentElement.dataset.theme=dark?"dark":"light";document.getElementById("theme-button").innerHTML=icon(dark?"sun":"moon");window.CRADevice?.theme(dark);}
window.setNativeTheme=value=>{if(!themeChosen)setTheme(value);};
setTheme(dark);
function invalidate() {const result=document.getElementById("results");if(result)result.innerHTML="";}
function home() {
state.mode="home";
main.innerHTML='<section class="hero"><p class="eyebrow">Your return, understood</p><h1>See what changed.<br>Know what follows.</h1><p>Compare two tax returns or explore an adjustment. Every result stays tied to the evidence you confirm.</p></section>'+
'<section class="home-grid" aria-label="Choose a tool">'+
'<button class="feature" data-action="compare"><span class="feature-icon">'+icon("compare")+'</span><h2>Compare &amp; Explain</h2><p>Scan the original and revised return. See each change and the effect shown in your documents.</p><span class="start">Compare returns '+icon("arrow")+'</span></button>'+
'<button class="feature simulate" data-action="simulate"><span class="feature-icon">'+icon("simulate")+'</span><h2>Simulate Adjustment</h2><p>Start with the original return, edit multiple lines and follow the supported calculation steps.</p><span class="start">Explore an adjustment '+icon("arrow")+'</span></button></section>'+
'<div class="privacy">'+icon("shield")+'<div><b>Private by design</b>Photos and return amounts stay on this device, in this session. OCR runs locally. Tax rules are verified online against official CRA and Justice Canada references. Clear the session when you finish.</div></div>'+
'<div class="buttons">'+button('Clear session',"clear","text")+'</div>';
}
function render() {
if(state.mode==="home"){home();return;}
const compare=state.mode==="compare";
main.innerHTML='<div class="workflow-head"><button class="back" data-action="home">'+icon("back")+'All tools</button><h1>'+(compare?"Compare &amp; Explain":"Simulate Adjustment")+'</h1><p class="muted">'+(compare?"Read both versions, confirm the numbers, then explain the differences.":"Read the original return, confirm the numbers, then adjust any relevant line.")+'</p></div>'+
'<section class="card"><h2><span class="number">1</span>Return details</h2><div class="fields"><div class="field"><label for="tax-year">Tax year</label><input id="tax-year" type="number" inputmode="numeric" min="2019" max="2100" value="'+state.year+'"></div><div class="field"><label for="province">Jurisdiction</label><select id="province">'+
[["QC","Quebec"],["ON","Ontario"],["BC","British Columbia"],["AB","Alberta"],["MB","Manitoba"],["NB","New Brunswick"],["NL","Newfoundland and Labrador"],["NS","Nova Scotia"],["NT","Northwest Territories"],["NU","Nunavut"],["PE","Prince Edward Island"],["SK","Saskatchewan"],["YT","Yukon"],["NONRES","Non-resident / special return"]].map(([code,name])=>'<option value="'+code+'" '+(state.province===code?"selected":"")+'>'+name+'</option>').join("")+
'</select></div></div>'+
(compare?'<label class="check"><input type="checkbox" id="same-context" '+(state.same?"checked":"")+'>Both documents concern the same taxpayer, tax year and jurisdiction.</label>':
'<p class="note">Mapped rules: selected 2025 federal calculations. Other years and unsupported dependencies are identified in the results.</p>')+'</section>'+
'<section class="card"><div class="head"><h2><span class="number">2</span>Scan &amp; confirm</h2></div><p class="subtitle">Include the line numbers and amounts. Add more photos for additional pages. Confirm every extracted value you use.</p><div class="doc-grid '+(compare?"":"single")+'">'+docHTML("before")+(compare?docHTML("after"):"")+'</div></section>'+
(compare?"":'<section class="card"><h2><span class="number">3</span>Requested adjustments</h2><p class="subtitle">Enter the new amount for each line. Add a missing original line above before changing it here.</p><div id="edits">'+editsHTML()+'</div>'+button(icon("plus")+"Add another line","add-edit","text")+
'<label class="check"><input type="checkbox" id="scope" '+(state.scope?"checked":"")+'>I verified that the entered amounts are allowable claims for a full-year resident. Other linked claims stay unchanged. This case has no AMT, TOSI, foreign surtax, tax recapture, logging tax credit, or business establishment outside this province. Special returns need separate rules.</label></section>')+
'<div class="run-bar">'+button(icon(compare?"compare":"simulate")+(compare?"Compare confirmed values":"Simulate adjustment"),"run")+'<div class="buttons">'+button("Fictional example","demo","text")+button("Clear session","clear","text danger")+'</div></div><div id="results" aria-live="polite"></div>';
renderPreviews();
const contextCard=document.querySelector('section.card');
if(contextCard){const box=document.createElement('div');box.id='official-sources';box.innerHTML=sourcesHTML();contextCard.appendChild(box);}
}
function docHTML(side) {
const title=side==="before"?"Original return":"Revised return";
const rows=Object.entries(state.docs[side]).sort(([a],[b])=>a.localeCompare(b));
return '<section class="doc" data-side="'+side+'"><div class="doc-title">'+icon("document")+'<h3>'+title+'</h3></div><p class="subtitle">Multiple pages supported</p><div class="buttons upload-actions">'+
button(icon("camera")+"Take photo","photo","","data-side="+side)+button(icon("upload")+"Upload photos","upload","outline","data-side="+side)+'</div>'+
'<input class="sr-only" tabindex="-1" aria-label="'+title+' camera" id="camera-'+side+'" type="file" accept="image/*" capture="environment"><input class="sr-only" tabindex="-1" aria-label="'+title+' photos" id="files-'+side+'" type="file" accept="image/*" multiple>'+
'<div class="previews" id="previews-'+side+'"></div>'+button("Read photos on device","ocr","secondary wide","data-side="+side+(state.busy?" disabled":""))+
'<div class="status" id="status-'+side+'" role="status">'+state.photos[side].length+' photo(s) in this session</div>'+
'<div class="review"><div class="review-header"><h3>Extracted lines</h3>'+chip(rows.filter(([,r])=>r.confirmed).length+" / "+rows.length+" confirmed","info")+'</div>'+
(rows.length?rows.map(([line,r])=>lineHTML(side,line,r)).join(""):'<p class="empty">Read a photo or add a line manually.</p>')+'</div>'+
'<div class="add-line"><div class="fields"><div class="field"><label for="add-line-'+side+'">Line</label><input id="add-line-'+side+'" inputmode="numeric" maxlength="5" placeholder="15000"></div><div class="field"><label for="add-amount-'+side+'">Amount (CAD)</label><input id="add-amount-'+side+'" inputmode="decimal" placeholder="0.00"></div></div>'+
button(icon("plus")+"Add confirmed line","add-line","outline","data-side="+side)+'</div>'+
'<details><summary>Paste recognized text or enter several lines</summary><p>Use one line and amount per row, for example: Line 15000 $50,000.00. Imported values require confirmation.</p><textarea id="paste-'+side+'" aria-label="Recognized text for '+title+'" placeholder="Line 15000 $50,000.00"></textarea>'+button("Extract pasted lines","paste","text","data-side="+side)+'</details></section>';
}
function lineHTML(side,line,r) {
const name=r.description||E.info(line).n;
return '<div class="line-row" data-side="'+side+'" data-line="'+line+'"><div class="meta"><span class="name">'+esc(name)+'</span></div><div class="line-inputs">'+
'<input aria-label="'+side+' line '+line+'" data-field="line" inputmode="numeric" maxlength="5" value="'+line+'">'+
'<input aria-label="'+side+' amount '+line+'" data-field="amount" inputmode="decimal" value="'+esc(r.raw??E.amountText(r.amount))+'" '+(r.amount===null?'aria-invalid="true"':"")+'>'+
'<button class="icon-button" data-action="remove-line" data-side="'+side+'" data-line="'+line+'" aria-label="Remove line '+line+'">×</button></div>'+
'<div class="confirm-row"><label><input type="checkbox" data-field="confirmed" aria-label="Confirm '+side+' '+line+'" '+(r.confirmed?"checked":"")+'>Verified</label>'+chip(r.confirmed?"Confirmed":"Review required",r.confirmed?"ok":"warn")+'</div>'+
(r.confirmed?"":'<p class="note">'+esc(r.reason||"Check the line number and amount against the original.")+'</p>')+
(r.evidence?'<details><summary>Source text</summary><div class="evidence">'+esc(r.evidence)+'</div></details>':"")+'</div>';
}
function editsHTML() {
if(!state.edits.length)return '<p class="empty">No adjustments added.</p>';
return state.edits.map((e,i)=>'<div class="edit-row" data-edit="'+i+'"><div class="field"><label for="edit-line-'+i+'">Line</label><input id="edit-line-'+i+'" data-edit-field="line" inputmode="numeric" maxlength="5" value="'+esc(e.line)+'"></div><div class="field"><label for="edit-amount-'+i+'">New amount (CAD)</label><input id="edit-amount-'+i+'" data-edit-field="raw" inputmode="decimal" value="'+esc(e.raw)+'"></div><button class="icon-button" data-action="remove-edit" data-index="'+i+'" aria-label="Remove adjustment">×</button><div class="edit-name">'+esc(E.info(e.line).n)+' · Original: '+E.money(E.get(state.docs.before,e.line))+'</div></div>').join("");
}
function renderPreviews() {
for(const side of ["before","after"]) {
const box=document.getElementById("previews-"+side);if(!box)continue;
box.innerHTML=state.photos[side].map((p,i)=>'<div class="photo"><img src="'+p.url+'" alt="'+side+' return page '+(i+1)+'"><button data-action="remove-photo" data-side="'+side+'" data-index="'+i+'" aria-label="Remove photo '+(i+1)+'">×</button><span>Page '+(i+1)+'</span></div>').join("");
}
}
async function fileToCanvas(file) {
const url=URL.createObjectURL(file);
try {
const img=await new Promise((resolve,reject)=>{const i=new Image();i.onload=()=>resolve(i);i.onerror=reject;i.src=url;});
const scale=Math.min(1,2400/Math.max(img.naturalWidth,img.naturalHeight));
const canvas=document.createElement("canvas");canvas.width=Math.max(1,Math.round(img.naturalWidth*scale));canvas.height=Math.max(1,Math.round(img.naturalHeight*scale));
const ctx=canvas.getContext("2d",{willReadFrequently:false});ctx.fillStyle="#fff";ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0,canvas.width,canvas.height);return canvas;
} finally {URL.revokeObjectURL(url);}
}
async function addPhotos(side,files) {
const epoch=state.epoch;
for(const file of files) {
if(!file.type.startsWith("image/")){toast("Choose image files.");continue;}
if(state.photos[side].length>=20){toast("Use up to 20 pages per return.");break;}
if(file.size>30*1024*1024){toast("This photo is too large. Choose a smaller image.");continue;}
try {
const canvas=await fileToCanvas(file),blob=await new Promise(resolve=>canvas.toBlob(resolve,"image/jpeg",.94));
canvas.width=1;canvas.height=1;
if(!blob)throw new Error("Image conversion failed.");
if(epoch!==state.epoch)return;
state.photos[side].push({blob,url:URL.createObjectURL(blob),read:false});
} catch(error){toast("Could not open the photo. Try a JPEG or PNG image.");}
}
window.CRADevice?.clearPhotos();
invalidate();render();
}
let ocrSequence=0;
const waiting=new Map();
window.onNativeOcr=(id,result)=>{const pending=waiting.get(id);if(!pending)return;clearTimeout(pending.timer);waiting.delete(id);result.error?pending.reject(new Error(result.error)):pending.resolve(result.text||"");};
function nativeOCR(base64) {
if(!window.CRADevice?.recognize)return Promise.reject(new Error("Photo OCR runs in the Android app. You can paste text or enter amounts here."));
const id="ocr-"+(++ocrSequence);
return new Promise((resolve,reject)=>{
const timer=setTimeout(()=>{waiting.delete(id);reject(new Error("OCR took too long. Try one sharper photo."));},90000);
waiting.set(id,{resolve,reject,timer});
window.CRADevice.recognize(id,base64);
});
}
async function readPhotos(side) {
if(state.busy)return;
const unread=state.photos[side].filter(p=>!p.read);
if(!unread.length){toast("Add a photo to read.");return;}
const epoch=state.epoch;state.busy=true;
document.querySelectorAll('[data-action="ocr"]').forEach(b=>b.disabled=true);
try {
for(let i=0;i<unread.length;i++){
const status=document.getElementById("status-"+side);if(status)status.textContent="Reading page "+(i+1)+" of "+unread.length+" on this device…";
const canvas=await fileToCanvas(unread[i].blob);
const text=await nativeOCR(canvas.toDataURL("image/jpeg",.94).split(",")[1]);canvas.width=1;canvas.height=1;
if(epoch!==state.epoch)return;
const parsed=E.parseOCR(text,"Photo "+(state.photos[side].indexOf(unread[i])+1));
state.docs[side]=E.mergeOCR(state.docs[side],parsed.lines);unread[i].read=true;
if(parsed.warnings.length)toast(parsed.warnings[0]);
}
toast("OCR complete. Verify each line and amount before analysis.");
}catch(error){toast(error.message);}
finally{state.busy=false;if(epoch===state.epoch)render();}
}
function resultHTML(result,compare) {
const rows=compare?result.rows.filter(r=>r.change!==0):result.rows;
let html='<div class="result-title"><h2>Results</h2>'+chip(compare?"Document comparison":"Conditional estimate","info")+'</div><div class="legend">'+chip("Confirmed / observed","ok")+chip("Calculated","info")+chip("Needs review","warn")+'</div>';
if(result.final) {
const f=result.final;
html+='<div class="result-hero"><span class="chip info">Calculated consequence</span><p>'+(compare?"Revised federal T1 outcome":"Estimated federal T1 outcome")+'</p><div class="amount">'+E.money(Math.abs(f.after))+'</div><b>'+(f.after>0?"Refund":f.after<0?"Balance owing":"No refund or balance")+'</b><p>Before: '+E.money(Math.abs(f.before))+' '+(f.before>=0?"refund":"owing")+' · Change in taxpayer position: '+E.money(f.change)+'</p></div>';
}else html+='<div class="notice warn"><strong>Final outcome unavailable</strong>Only confirmed document changes and supported intermediate steps are shown. Complete the missing evidence or mapped dependencies below.</div>';
if(result.issues.length)html+='<section class="card"><h3>What is still needed</h3>'+result.issues.map(i=>'<div class="notice warn"><strong>'+esc(i.code==="dependency not yet mapped"?"Dependency not yet mapped":i.code==="missing"?"More evidence needed":"Review required")+'</strong>'+esc(i.message)+'</div>').join("")+'</section>';
if(compare)html+='<section class="card"><h3>Impact visible in the documents</h3>'+tableHTML(result.impacts)+"<p class=\"note\">These are confirmed total-line differences. They do not attribute one line's impact to a particular cause.</p></section>";
html+='<section class="card"><h3>'+(compare?"Changed lines":"Adjustment & calculation steps")+'</h3>'+
(rows.length?tableHTML(rows):'<p class="empty">No confirmed changes to show.</p>')+
rows.map(r=>'<article class="change-card">'+chip(r.type,r.type==="observed change"?"ok":r.type==="requested adjustment"?"warn":"info")+'<h3>'+esc(r.line==="federal_gross"?"Federal bracket tax":"Line "+r.line)+' · '+esc(r.description)+'</h3><div class="change-values">'+E.money(r.before)+' → <b>'+E.money(r.after)+'</b> · Change '+E.money(r.change)+'</div>'+
(compare?chip("Possible explanation","warn"):"")+'<p>'+esc(r.explanation)+'</p></article>').join("")+'</section>';
html+='<div class="notice info">'+esc(compare?result.possibleExplanation:result.province)+'</div>';
if(!compare)html+='<p class="note">'+esc(result.note)+'</p>';
return html+'<p class="source-note">Rules reference: CRA 2025 T1, Steps 3–6; lines 34990 and 44000. Rule scope and limitations are documented with the app source.</p>';
}
function tableHTML(rows) {
return '<div class="table-wrap"><table><thead><tr><th>Line</th><th>Before</th><th>After</th><th>Change</th></tr></thead><tbody>'+rows.map(r=>'<tr><td>'+esc(r.line==="federal_gross"?"Bracket tax":r.line)+'</td><td>'+E.money(r.before)+'</td><td>'+E.money(r.after)+'</td><td>'+E.money(r.change)+'</td></tr>').join("")+'</tbody></table></div>';
}
function run() {
const verification=O.check(sourceRecords,state.year,state.province);
const context={year:state.year,province:state.province,sameContext:state.same,scopeConfirmed:state.scope,officialVerified:verification.verified};
if(state.mode!=="compare" && !verification.verified)refreshSources();
const r=state.mode==="compare"?E.compare(state.docs.before,state.docs.after,context):E.simulate(state.docs.before,state.edits.map(e=>({line:e.line,amount:E.parseMoney(e.raw)})),context);
document.getElementById("results").innerHTML=resultHTML(r,state.mode==="compare");
document.getElementById("results").scrollIntoView({behavior:"smooth",block:"start"});
}
function demo() {
clear(false);
state.year=2025;state.province="QC";state.same=true;state.scope=true;
const values={"15000":50000,"23300":0,"23400":50000,"23500":0,"23600":50000,"25700":0,"26000":50000,"31800":0,"31900":0,"33500":20000,"33800":2900,"34900":0,"34990":0,"35000":2900,"40400":7250,"40424":0,"40425":0,"40427":0,"40500":0,"41000":0,"41200":0,"41400":0,"41500":0,"41800":0,"42900":4350,"42000":4350,"42800":0,"43500":4350,"43700":6000,"44000":717.75,"47600":0,"48200":6717.75,"48400":2367.75,"48500":0};
for(const [line,dollars] of Object.entries(values))state.docs.before[line]={amount:Math.round(dollars*100),confirmed:true,source:"Fictional sample"};
state.edits=[{line:"31800",raw:"1000.00"},{line:"31900",raw:"200.00"}];
state.docs.after=JSON.parse(JSON.stringify(state.docs.before));
const simulation=E.simulate(state.docs.before,state.edits.map(e=>({line:e.line,amount:E.parseMoney(e.raw)})),{year:2025,province:"QC",scopeConfirmed:true,officialVerified:true});
for(const row of simulation.rows)if(E.validLine(row.line))state.docs.after[row.line]={amount:row.after,confirmed:true,source:"Fictional sample"};
render();toast("Fictional example loaded. No personal information.");
}
function clear(show=true) {
state.epoch++;
for(const side of ["before","after"]){for(const p of state.photos[side])URL.revokeObjectURL(p.url);state.photos[side]=[];state.docs[side]={};}
state.edits=[];state.scope=false;state.same=false;
window.CRADevice?.clearPhotos();
if(show){render();toast("Session cleared.");}
}
window.goHome=()=>{if(state.mode==="home"){toast("You are on the home screen.");return;}home();window.scrollTo(0,0);};
document.addEventListener("click",event=>{
const b=event.target.closest("[data-action]");if(!b || b.disabled)return;
const side=b.dataset.side,action=b.dataset.action;
if(action==="theme"){themeChosen=true;setTheme(!dark);return;}
if(action==="home"){window.goHome();return;}
if(action==="compare" || action==="simulate"){state.mode=action;render();refreshSources();window.scrollTo(0,0);return;}
if(action==="refresh-sources"){refreshSources(true);return;}
if(action==="open-source"){openSource(b.dataset.source);return;}
if(action==="clear"){clear();return;}
if(action==="demo"){demo();return;}
if(action==="run"){run();return;}
if(action==="photo" || action==="upload"){document.getElementById((action==="photo"?"camera-":"files-")+side).click();return;}
if(action==="ocr"){readPhotos(side);return;}
if(action==="remove-photo"){const p=state.photos[side].splice(Number(b.dataset.index),1)[0];if(p)URL.revokeObjectURL(p.url);render();return;}
if(action==="remove-line"){delete state.docs[side][b.dataset.line];render();return;}
if(action==="add-line"){
const line=document.getElementById("add-line-"+side).value.trim(),raw=document.getElementById("add-amount-"+side).value.trim(),amount=E.parseMoney(raw);
if(!E.validLine(line) || amount===null){toast("Enter a five-digit line and a valid amount. Enter 0 explicitly when applicable.");return;}
if(state.docs[side][line]){toast("This line already exists. Edit its amount above.");return;}
state.docs[side][line]={amount,confirmed:true,source:"Manual",description:E.info(line).n};render();return;
}
if(action==="paste"){
const parsed=E.parseOCR(document.getElementById("paste-"+side).value,"Pasted text");
state.docs[side]=E.mergeOCR(state.docs[side],parsed.lines);render();toast(parsed.warnings[0]||"Lines extracted. Verify each amount.");return;
}
if(action==="add-edit"){state.edits.push({line:"",raw:""});invalidate();document.getElementById("edits").innerHTML=editsHTML();return;}
if(action==="remove-edit"){state.edits.splice(Number(b.dataset.index),1);invalidate();document.getElementById("edits").innerHTML=editsHTML();}
});
document.addEventListener("input",event=>{
const el=event.target;
if(el.id==="tax-year"){state.year=Number(el.value);invalidate();updateSourcesUI();}
if(el.dataset.editField) {const row=el.closest("[data-edit]");state.edits[Number(row.dataset.edit)][el.dataset.editField]=el.value.trim();invalidate();}
if(el.dataset.field==="amount") {const row=el.closest(".line-row"),r=state.docs[row.dataset.side][row.dataset.line];r.raw=el.value;r.amount=E.parseMoney(el.value);r.confirmed=false;const check=row.querySelector('[data-field="confirmed"]');check.checked=false;row.querySelector(".chip").textContent="Review required";row.querySelector(".chip").className="chip warn";el.setAttribute("aria-invalid",r.amount===null?"true":"false");invalidate();}
});
document.addEventListener("change",event=>{
const el=event.target;
if(el.type==="file"){const side=el.id.endsWith("before")?"before":"after";addPhotos(side,[...el.files]);el.value="";return;}
if(el.id==="province"){state.province=el.value;invalidate();updateSourcesUI();return;}
if(el.id==="same-context"){state.same=el.checked;invalidate();return;}
if(el.id==="scope"){state.scope=el.checked;invalidate();return;}
const row=el.closest(".line-row");if(!row)return;
const side=row.dataset.side,line=row.dataset.line,r=state.docs[side][line];
if(el.dataset.field==="confirmed"){if(r.amount===null){el.checked=false;toast("Enter a valid amount before confirming.");return;}r.confirmed=el.checked;render();}
if(el.dataset.field==="line"){
const next=el.value.trim();
if(!E.validLine(next) || (next!==line && state.docs[side][next])){el.value=line;toast("Use a unique five-digit line.");return;}
if(next!==line){state.docs[side][next]={...r,confirmed:false,description:E.info(next).n};delete state.docs[side][line];render();}
}
});
function sourcesHTML() {
const verification=O.check(sourceRecords,state.year,state.province);
return '<details><summary>Official sources · '+(verification.verified?'checked online':'verification needed')+'</summary><p>Read current CRA guidance and legislation directly. Calculations use year-specific validated rules. A changed form or law stops affected estimates until the rules are reviewed.</p>'+
button('Check official sources now','refresh-sources','outline')+
Object.entries(O.sources).map(([id,s])=>{
const r=sourceRecords[id];
const status=r?.ok?'Checked '+new Date(r.checkedAt).toLocaleString():r?.pending?'Checking official website…':r?.error||'Not checked this session';
return '<div class="source-row">'+button(esc(s.title),'open-source','text','data-source="'+id+'"')+'<p class="note">'+esc(status)+(r?.currentTo?' · Consolidation current to '+esc(r.currentTo):'')+(r?.amended?' · Amended '+esc(r.amended):'')+(r?.modified?' · Page updated '+esc(r.modified):'')+'</p></div>';
}).join('')+
(verification.verified?'<div class="notice ok">The official 2025 forms match the implemented rule version. Legislation references were retrieved online. This verifies source versions, not the eligibility of a claim.</div>':
'<div class="notice warn">'+verification.reasons.map(esc).join('<br>')+'</div>')+
'<p class="note">Only public reference URLs are requested. Return photos, amounts and identifiers are never sent. Opening a source uses your browser.</p></details>';
}
function updateSourcesUI() {
const box=document.getElementById('official-sources');
if(box){const open=box.querySelector('details')?.open;box.innerHTML=sourcesHTML();if(open)box.querySelector('details').open=true;}
}
window.onOfficialSource=result=>{
if(!O.sources[result.id])return;
sourceRecords[result.id]=result;
invalidate();updateSourcesUI();
};
function refreshSources(force=false) {
if(!window.CRADevice?.fetchOfficial){updateSourcesUI();return;}
for(const id of Object.keys(O.sources)){
const r=sourceRecords[id];
if(r?.pending || (!force && r?.ok && Date.now()-r.checkedAt<86400000))continue;
sourceRecords[id]={pending:true};
window.CRADevice.fetchOfficial(id);
}
updateSourcesUI();
}
function openSource(id) {
if(!O.sources[id])return;
if(window.CRADevice?.openOfficial)window.CRADevice.openOfficial(id);
else window.open(O.sources[id].url,'_blank','noopener,noreferrer');
}
window.addEventListener("pagehide",()=>clear(false));
home();
})();
