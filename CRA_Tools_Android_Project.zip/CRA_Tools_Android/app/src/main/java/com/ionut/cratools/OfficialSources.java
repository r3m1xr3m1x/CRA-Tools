package com.ionut.cratools;

import android.text.Html;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONObject;

/** Only fixed, public official references. Never receives a taxpayer value, image, or arbitrary URL. */
final class OfficialSources {
    static final Map<String,String> URLS = new LinkedHashMap<>();
    static {
        URLS.put("t1","https://www.canada.ca/content/dam/cra-arc/formspubs/pbg/5000-r/5000-r-25e.txt");
        URLS.put("quebec","https://www.canada.ca/content/dam/cra-arc/formspubs/pbg/5005-r/5005-r-25e.txt");
        URLS.put("topup","https://www.canada.ca/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/tax-return/completing-a-tax-return/deductions-credits-expenses/line-34990-top-up-tax-credit.html");
        URLS.put("abatement","https://www.canada.ca/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/tax-return/completing-a-tax-return/deductions-credits-expenses/line-44000-refundable-quebec-abatement.html");
        URLS.put("act","https://laws-lois.justice.gc.ca/eng/acts/I-3.3/");
        URLS.put("regulations","https://laws-lois.justice.gc.ca/eng/regulations/C.R.C.,_c._945/");
        URLS.put("current","https://www.canada.ca/en/revenue-agency/services/tax/individuals/tax-rates-brackets/current-year.html");
        URLS.put("news","https://www.canada.ca/en/revenue-agency/services/tax/individuals/topics/about-your-tax-return/tax-return/completing-a-tax-return/whats-new.html");
    }
    static boolean allowed(URL url) {
        return "https".equals(url.getProtocol()) && (url.getPort()==-1 || url.getPort()==443)
            && ("www.canada.ca".equals(url.getHost()) || "laws-lois.justice.gc.ca".equals(url.getHost()));
    }
    static JSONObject fetch(String id) {
        JSONObject out = new JSONObject();
        try {
            out.put("id",id);
            String address=URLS.get(id);
            if(address==null)throw new IllegalArgumentException("Unknown reference");
            out.put("url",address);
            URL url=new URL(address);
            byte[] bytes=null;
            for(int redirect=0;redirect<4;redirect++) {
                if(!allowed(url))throw new IllegalArgumentException("Non-official redirect");
                HttpURLConnection connection=(HttpURLConnection)url.openConnection();
                try {
                    connection.setInstanceFollowRedirects(false);
                    connection.setConnectTimeout(15000);
                    connection.setReadTimeout(15000);
                    connection.setUseCaches(false);
                    connection.setRequestProperty("Cache-Control","no-cache");
                    connection.setRequestProperty("Accept","text/html,text/plain,application/txt");
                    int code=connection.getResponseCode();
                    if(code>=300 && code<400) {
                        String next=connection.getHeaderField("Location");
                        if(next==null)throw new IllegalStateException("Missing redirect");
                        url=new URL(url,next);
                        continue;
                    }
                    if(code!=200)throw new IllegalStateException("Official source unavailable");
                    try(InputStream in=connection.getInputStream();ByteArrayOutputStream buffer=new ByteArrayOutputStream()) {
                        byte[] chunk=new byte[8192];int count;
                        while((count=in.read(chunk))!=-1) {
                            if(buffer.size()+count>2_000_000)throw new IllegalStateException("Reference too large");
                            buffer.write(chunk,0,count);
                        }
                        bytes=buffer.toByteArray();
                    }
                    break;
                } finally {connection.disconnect();}
            }
            if(bytes==null)throw new IllegalStateException("Too many redirects");
            String raw=new String(bytes,StandardCharsets.UTF_8);
            String canonical=raw.replace("\r\n","\n").trim();
            MessageDigest digest=MessageDigest.getInstance("SHA-256");
            StringBuilder hash=new StringBuilder();
            for(byte b:digest.digest(canonical.getBytes(StandardCharsets.UTF_8)))hash.append(String.format("%02x",b&255));
            String plain=("t1".equals(id) || "quebec".equals(id))?canonical:
                Html.fromHtml(raw.replaceAll("(?is)<(script|style)\\b[^>]*>.*?</\\1>",""),Html.FROM_HTML_MODE_COMPACT).toString().replaceAll("\\s+"," ");
            out.put("hash",hash.toString());
            out.put("checkedAt",System.currentTimeMillis());
            out.put("currentTo",find(plain,"(?i)current to\\s+(\\d{4}-\\d{2}-\\d{2})"));
            out.put("amended",find(plain,"(?i)last amended\\s+on\\s+(\\d{4}-\\d{2}-\\d{2})"));
            out.put("modified",find(raw,"(?i)name=[\"']dcterms.modified[\"'][^>]*content=[\"']([^\"']+)"));
            if("topup".equals(id))out.put("signals",plain.contains("14.5%") && plain.contains("57,375") && plain.contains("2025"));
            out.put("ok",true);
        } catch(Exception error) {
            try {out.put("ok",false);out.put("error","Unable to verify this official source. Check your connection and retry.");}
            catch(Exception ignored) {}
        }
        return out;
    }
    private static String find(String text,String regex) {
        Matcher match=Pattern.compile(regex).matcher(text);
        return match.find()?match.group(1):"";
    }
}
