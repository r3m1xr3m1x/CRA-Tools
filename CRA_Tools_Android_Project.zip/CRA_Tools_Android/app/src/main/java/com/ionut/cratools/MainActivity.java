package com.ionut.cratools;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private Uri cameraUri;
    private boolean cameraCapture;
    private boolean recognizing;
    private TextRecognizer recognizer;
    private final ExecutorService imageExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService sourceExecutor = Executors.newFixedThreadPool(3);

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        clearTemporaryPhotos();
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        webView = new WebView(this);
        setContentView(webView);
        ViewCompat.setOnApplyWindowInsetsListener(webView, (view, insets) -> {
            androidx.core.graphics.Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.ime());
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSaveFormData(false);
        webView.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
        webView.addJavascriptInterface(new LocalOcrBridge(), "CRADevice");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !request.getUrl().toString().startsWith("file:///android_asset/");
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                if ("http".equals(scheme) || "https".equals(scheme))
                    return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
                return super.shouldInterceptRequest(view, request);
            }
            @Override public void onPageFinished(WebView view, String url) {
                boolean dark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
                webView.evaluateJavascript("window.setNativeTheme && window.setNativeTheme(" + dark + ")", null);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                cameraCapture = params.isCaptureEnabled();
                try {
                    Intent intent;
                    if (cameraCapture) {
                        File dir = new File(getCacheDir(), "photos");
                        if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Camera cache unavailable");
                        File file = File.createTempFile("capture-", ".jpg", dir);
                        cameraUri = FileProvider.getUriForFile(MainActivity.this, getPackageName()+".photos", file);
                        intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        intent.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
                        intent.setClipData(ClipData.newRawUri("Photo", cameraUri));
                        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } else {
                        intent = new Intent(Intent.ACTION_GET_CONTENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("image/*");
                        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    }
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception error) {
                    filePathCallback.onReceiveValue(null);
                    filePathCallback = null;
                    clearTemporaryPhotos();
                    Toast.makeText(MainActivity.this, cameraCapture ? "Camera unavailable. Use Upload photos." : "No image picker is available.", Toast.LENGTH_LONG).show();
                    return true;
                }
            }
        });
        // Do not restore taxpayer data across Activity/process recreation.
        webView.loadUrl("file:///android_asset/index.html");
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQUEST || filePathCallback == null) return;
        Uri[] results = null;
        if (resultCode == Activity.RESULT_OK) {
            if (cameraCapture && cameraUri != null) results = new Uri[] {cameraUri};
            else if (data != null && data.getClipData() != null) {
                int count = Math.min(data.getClipData().getItemCount(), 20);
                results = new Uri[count];
                for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data != null && data.getData() != null) results = new Uri[] {data.getData()};
        } else if(cameraCapture) clearTemporaryPhotos();
        filePathCallback.onReceiveValue(results);
        filePathCallback = null;
        cameraUri = null;
    }
    private void sendOcr(String id, JSONObject result) {
        runOnUiThread(() -> {
            recognizing = false;
            if (webView != null) webView.evaluateJavascript(
                "window.onNativeOcr && window.onNativeOcr(" + JSONObject.quote(id) + "," + result + ")", null);
        });
    }
    private JSONObject failure() {
        JSONObject out = new JSONObject();
        try {out.put("error", "Local OCR could not read this image. Try a sharper photo or enter the lines manually.");}
        catch(Exception ignored) {}
        return out;
    }
    // Associate amount columns across OCR blocks by their vertical position.
    static String spatialRows(Text text) {
        List<Text.Line> lines = new ArrayList<>();
        for(Text.TextBlock block : text.getTextBlocks()) lines.addAll(block.getLines());
        lines.sort(Comparator.comparingInt(line -> line.getBoundingBox() == null ? 0 : line.getBoundingBox().centerY()));
        List<List<Text.Line>> rows = new ArrayList<>();
        for(Text.Line line : lines) {
            Rect box = line.getBoundingBox();
            if(box == null) continue;
            List<Text.Line> row = rows.isEmpty() ? null : rows.get(rows.size()-1);
            Rect first = row == null ? null : row.get(0).getBoundingBox();
            if(first == null || Math.abs(first.centerY()-box.centerY()) > Math.max(5, Math.min(first.height(),box.height())*.45)) {
                row = new ArrayList<>();
                rows.add(row);
            }
            row.add(line);
        }
        StringBuilder out = new StringBuilder();
        for(List<Text.Line> row : rows) {
            row.sort(Comparator.comparingInt(line -> line.getBoundingBox().left));
            for(Text.Line line : row) out.append(line.getText()).append(" ");
            out.append("\n");
        }
        return out.toString();
    }
    private final class LocalOcrBridge {
        @JavascriptInterface public void recognize(String id, String base64) {
            if(id == null || !id.matches("[a-zA-Z0-9-]{1,80}"))return;
            runOnUiThread(() -> {
                if(recognizing || base64 == null || base64.length()>24_000_000) {sendOcr(id,failure());return;}
                recognizing = true;
                imageExecutor.execute(() -> {
                    Bitmap bitmap = null;
                    try {
                        byte[] bytes = android.util.Base64.decode(base64, android.util.Base64.DEFAULT);
                        BitmapFactory.Options bounds = new BitmapFactory.Options();
                        bounds.inJustDecodeBounds = true;
                        BitmapFactory.decodeByteArray(bytes,0,bytes.length,bounds);
                        if(bounds.outWidth<=0 || bounds.outHeight<=0 || (long)bounds.outWidth*bounds.outHeight>25_000_000L)
                            throw new IllegalArgumentException("Image dimensions");
                        bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                        if(bitmap == null)throw new IllegalArgumentException("Invalid image");
                        Bitmap inputBitmap = bitmap;
                        recognizer.process(InputImage.fromBitmap(bitmap,0))
                            .addOnSuccessListener(text -> {
                                JSONObject out = new JSONObject();
                                try {out.put("text",spatialRows(text));}catch(Exception ignored) {}
                                sendOcr(id,out);
                            })
                            .addOnFailureListener(error -> sendOcr(id,failure()))
                            .addOnCompleteListener(task -> inputBitmap.recycle());
                    } catch(Exception | OutOfMemoryError error) {
                        if(bitmap != null)bitmap.recycle();
                        sendOcr(id,failure());
                    }
                });
            });
        }
        @JavascriptInterface public void fetchOfficial(String id) {
            if(!OfficialSources.URLS.containsKey(id))return;
            sourceExecutor.execute(() -> {
                JSONObject result=OfficialSources.fetch(id);
                runOnUiThread(() -> {
                    if(webView!=null)webView.evaluateJavascript("window.onOfficialSource && window.onOfficialSource("+result+")",null);
                });
            });
        }
        @JavascriptInterface public void openOfficial(String id) {
            String address=OfficialSources.URLS.get(id);
            if(address==null)return;
            runOnUiThread(() -> {
                try {startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(address)));}
                catch(Exception error) {Toast.makeText(MainActivity.this,"No browser is available.",Toast.LENGTH_SHORT).show();}
            });
        }
        @JavascriptInterface public void clearPhotos() {runOnUiThread(MainActivity.this::clearTemporaryPhotos);}
        @JavascriptInterface public void theme(boolean dark) {
            runOnUiThread(() -> {
                getWindow().setStatusBarColor(android.graphics.Color.parseColor(dark?"#101512":"#F5FBF7"));
                getWindow().setNavigationBarColor(android.graphics.Color.parseColor(dark?"#101512":"#F5FBF7"));
                getWindow().getDecorView().setSystemUiVisibility(dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
            });
        }
    }
    private void clearTemporaryPhotos() {
        File[] photos = new File(getCacheDir(),"photos").listFiles();
        if(photos != null)for(File photo : photos)photo.delete();
    }
    @Override public void onBackPressed() {
        if(webView != null)webView.evaluateJavascript("window.goHome && window.goHome()",null);
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if(filePathCallback != null)filePathCallback.onReceiveValue(null);
        imageExecutor.shutdownNow();
        sourceExecutor.shutdownNow();
        if(recognizer != null)recognizer.close();
        if(webView != null) {webView.removeJavascriptInterface("CRADevice");webView.clearCache(true);webView.destroy();webView=null;}
        clearTemporaryPhotos();
        super.onDestroy();
    }
}
