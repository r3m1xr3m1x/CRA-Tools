"""Read public official reference versions only. No return data is used or sent."""
import concurrent.futures
import hashlib
import html
import json
import re
import urllib.request
from pathlib import Path

source_js=(Path(__file__).resolve().parents[1]/"CRA_Tools_Android/app/src/main/assets/official-sources.js").read_text()
sources=re.findall(r'(\w+):\{title:"([^"]+)",url:"([^"]+)"(?:,hash:"([^"]+)")?\}',source_js)

def check(source):
    ident,title,url,expected=source
    req=urllib.request.Request(url,headers={"Cache-Control":"no-cache","User-Agent":"CRA-Tools-Reference-Validation/3.0"})
    with urllib.request.urlopen(req,timeout=25) as response:
        if response.status!=200: raise AssertionError(title+" unavailable")
        raw=response.read(2_000_001).decode("utf-8")
    if len(raw)>2_000_000: raise AssertionError("Unexpected reference size")
    if expected:
        actual=hashlib.sha256(raw.replace("\r\n","\n").strip().encode()).hexdigest()
        assert actual==expected,title+" changed; rules require review"
    plain=html.unescape(re.sub("<[^>]*>"," ",raw))
    plain=re.sub(r"\s+"," ",plain)
    suffix=""
    if ident in ("act","regulations"):
        current=re.search(r"current to\s+(\d{4}-\d{2}-\d{2})",plain,re.I)
        amended=re.search(r"last amended\s+on\s+(\d{4}-\d{2}-\d{2})",plain,re.I)
        assert current and amended,title+" metadata not found"
        assert amended[1]=="2026-06-18",title+" amendment changed"
        suffix="; current to "+current[1]+", amended "+amended[1]
    if ident=="topup":
        assert all(value in plain for value in ("14.5%","57,375","2025")),"Top-up reference changed"
    return title+": accessed successfully"+suffix

if __name__=="__main__":
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        for result in executor.map(check,sources):
            print(result)
    print("Official references verified: "+str(len(sources)))
