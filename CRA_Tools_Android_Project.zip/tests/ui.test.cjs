const assert=require("node:assert/strict"),path=require("node:path"),fs=require("node:fs");
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES?process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+"/playwright":"playwright");
const official=require("../CRA_Tools_Android/app/src/main/assets/official-sources");
(async()=>{
const browser=await chromium.launch({headless:true,...(process.env.CHROME_PATH?{executablePath:process.env.CHROME_PATH}:{}),args:["--no-sandbox"]});
const errors=[];
const page=await browser.newPage({viewport:{width:390,height:844},deviceScaleFactor:1});
page.on("pageerror",e=>errors.push(e.message));
const references=Object.fromEntries(Object.entries(official.sources).map(([id,s])=>[id,{id,ok:true,hash:s.hash,checkedAt:Date.now(),currentTo:"2026-09-30",amended:"2026-06-18",signals:true}]));
await page.addInitScript(ref=>{
window.CRADevice={
theme(){},clearPhotos(){},fetchOfficial(id){setTimeout(()=>window.onOfficialSource(ref[id]),0);},
recognize(id){setTimeout(()=>window.onNativeOcr(id,{text:"Line 15000 $50,000.00\nLine 26000 $48,000.00"}),0);}
};
},references);
await page.goto("file://"+path.resolve("CRA_Tools_Android/app/src/main/assets/index.html"));
assert.equal(await page.locator(".feature").count(),2);
assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
fs.mkdirSync("test-output",{recursive:true});
await page.screenshot({path:"test-output/home-light.png",fullPage:true});
await page.getByRole("button",{name:"Switch light or dark mode"}).click();
assert.equal(await page.locator("html").getAttribute("data-theme"),"dark");
await page.screenshot({path:"test-output/home-dark.png",fullPage:true});
await page.locator('[data-action="compare"]').click();
await page.locator('[data-action="demo"]').click();
await page.locator('[data-action="run"]').click();
await page.waitForSelector(".result-hero");
assert.match(await page.locator("#results").innerText(),/\$2,513\.04/);
assert.match(await page.locator("#results").innerText(),/observed change/);
await page.screenshot({path:"test-output/compare-mobile.png",fullPage:true});
// Alter an amount: confirmation is invalidated and stale results are cleared immediately.
await page.getByLabel("before amount 43500",{exact:true}).fill("4000.00");
assert.equal(await page.getByLabel("Confirm before 43500",{exact:true}).isChecked(),false);
assert.equal(await page.locator("#results").innerText(),"");
await page.locator('[data-action="run"]').click();
assert.equal(await page.locator(".result-hero").count(),0);
assert.match(await page.locator("#results").innerText(),/43500/);
await page.locator('[data-action="clear"]').click();
assert.equal(await page.locator(".line-row").count(),0);
// Multi-image intake with synthetic pictures; all OCR values remain unconfirmed.
const buffer=await page.screenshot();
await page.locator("#files-before").setInputFiles([{name:"fictional1.png",mimeType:"image/png",buffer},{name:"fictional2.png",mimeType:"image/png",buffer}]);
await page.waitForFunction(()=>document.querySelectorAll("#previews-before .photo").length===2);
await page.locator('[data-action="ocr"][data-side="before"]').click();
await page.waitForFunction(()=>document.querySelectorAll('.line-row[data-side="before"]').length===2);
assert.equal(await page.getByLabel("Confirm before 15000",{exact:true}).isChecked(),false);
await page.locator('[data-action="clear"]').click();
await page.locator('[data-action="home"]').first().click();
await page.locator('[data-action="simulate"]').click();
await page.locator('[data-action="demo"]').click();
await page.locator('[data-action="run"]').click();
await page.waitForSelector(".result-hero");
assert.match(await page.locator("#results").innerText(),/\$2,513\.04/);
assert.match(await page.locator("#results").innerText(),/Quebec provincial income tax is separate/);
assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
await page.screenshot({path:"test-output/simulate-mobile.png",fullPage:true});
// The user can supply any relevant line and a full new amount; no 31800-only field.
await page.locator("#edit-line-1").fill("77777");
await page.locator("#edit-amount-1").fill("345.67");
await page.locator('[data-action="run"]').click();
assert.equal(await page.locator(".result-hero").count(),0);
assert.match(await page.locator("#results").innerText(),/77777/);
// Server metadata changes must invalidate the live rule gate.
await page.evaluate(()=>window.onOfficialSource({id:"act",ok:true,checkedAt:Date.now(),currentTo:"2026-10-16",amended:"2026-10-15"}));
await page.locator('[data-action="demo"]').click();
await page.locator('[data-action="run"]').click();
assert.equal(await page.locator(".result-hero").count(),0);
assert.match(await page.locator("#results").innerText(),/Verify the current official CRA sources/);
await page.setViewportSize({width:1200,height:900});
await page.locator('[data-action="home"]').first().click();
await page.screenshot({path:"test-output/home-desktop.png",fullPage:true});
assert.deepEqual(errors,[]);
await browser.close();
console.log("UI checks passed: two tools, mobile/desktop, themes, comparison, OCR confirmation, two-page import, free line/amount edits, stale result clearing and changed-law gate.");
})().catch(error=>{console.error(error);process.exit(1);});
