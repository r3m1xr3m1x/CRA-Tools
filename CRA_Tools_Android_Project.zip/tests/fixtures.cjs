const amounts={15000:50000,23300:0,23400:50000,23500:0,23600:50000,25700:0,26000:50000,31800:0,31900:0,33500:20000,33800:2900,34900:0,34990:0,35000:2900,40400:7250,40424:0,40425:0,40427:0,40500:0,41000:0,41200:0,41400:0,41500:0,41800:0,42900:4350,42000:4350,42800:0,43500:4350,43700:6000,44000:717.75,47600:0,48200:6717.75,48400:2367.75,48500:0};
function doc(values=amounts){return Object.fromEntries(Object.entries(values).map(([line,v])=>[line,{amount:Math.round(v*100),confirmed:true}]));}
const ctx={year:2025,province:"QC",scopeConfirmed:true,officialVerified:true};
module.exports={amounts,doc,ctx};
