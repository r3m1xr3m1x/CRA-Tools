const {test}=require("node:test"),assert=require("node:assert/strict");
const E=require("../CRA_Tools_Android/app/src/main/assets/tax-engine");
const O=require("../CRA_Tools_Android/app/src/main/assets/official-sources");
const {doc,ctx}=require("./fixtures.cjs");
const edit=(line,value)=>({line,amount:E.parseMoney(value)});
test("money: English, French, spaces, negatives, zero and cent precision",()=>{
for(const s of ["$1,234.56","1 234,56","1.234,56","1\u202f234,56","CAD 1234.56","1234.56 $"])assert.equal(E.parseMoney(s),123456,s);
assert.equal(E.parseMoney("(1,234.56)"),-123456);assert.equal(E.parseMoney("−12.34"),-1234);
assert.equal(E.parseMoney("0"),0);assert.equal(E.parseMoney("0.01"),1);assert.equal(E.parseMoney("12.3"),1230);
});
test("money: no partial parse, malformed grouping, missing amounts or unsafe numbers",()=>{
for(const s of [""," ",null,"1,2,3","12 34","123abc","$","1,234.56 789.00","NaN","Infinity","99999999999999999","--1","(-2)"])assert.equal(E.parseMoney(s),null,s);
});
test("OCR: line label, same value as line code, comma decimals and bare known label",()=>{
const r=E.parseOCR("Line 15000 $15,000.00\nTaxable income 26000 12 345,67\nLigne 31800 $0.00").lines;
assert.equal(r["15000"].amount,1500000);assert.equal(r["26000"].amount,1234567);assert.equal(r["31800"].amount,0);
assert.ok(Object.values(r).every(v=>!v.confirmed));
});
test("OCR: any explicitly named five-digit line and normalized OCR zeros",()=>{
assert.equal(E.parseOCR("Line 150O0 $50,000.00").lines["15000"].amount,5000000);
assert.equal(E.parseOCR("Line 77777 $100.00").lines["77777"].amount,10000);
});
test("OCR: ambiguous multi-column values are not selected automatically",()=>{
const r=E.parseOCR("Line 15000 $50,000.00 | $52,000.00").lines["15000"];
assert.equal(r.amount,null);assert.equal(r.confirmed,false);
});
test("OCR: adjacent row recovery stops at another labelled row",()=>{
assert.equal(E.parseOCR("Line 15000\n$500.00").lines["15000"].amount,50000);
assert.equal(E.parseOCR("Line 15000\nLine 26000 $500.00").lines["15000"].amount,null);
});
test("OCR: duplicate lines/pages cannot overwrite a confirmed value",()=>{
const original={"15000":{amount:10000,confirmed:true,alternatives:[10000]}};
const merged=E.mergeOCR(original,{"15000":{amount:20000,confirmed:false,alternatives:[20000]}});
assert.equal(merged["15000"].amount,null);assert.equal(merged["15000"].confirmed,false);
assert.equal(original["15000"].amount,10000);
assert.equal(E.parseOCR("Line 15000 $100\nLine 15000 $200").lines["15000"].amount,null);
});
test("compare: multiple observed changes and independently reconciled outcome",()=>{
const a=doc(),b=doc();b["31800"].amount=100000;b["43500"].amount-=14500;b["48200"].amount-=2392;b["48400"].amount+=12108;
const result=E.compare(a,b,{sameContext:true});
assert.equal(result.final.change,12108);
assert.equal(result.rows.find(r=>r.line==="31800").type,"observed change");
assert.match(result.rows.find(r=>r.line==="31800").explanation,/does not reduce taxable income/);
});
test("compare: missing is not zero and exact missing lines are reported",()=>{
const r=E.compare(doc({"43500":500}),doc({"43500":400,"48200":1000}),{sameContext:true});
assert.equal(r.final,null);assert.ok(r.missing.before.includes("48200"));
});
test("compare: OCR values cannot enter calculations without confirmation",()=>{
const a=doc(),b=doc();b["43500"].confirmed=false;
const r=E.compare(a,b,{sameContext:true});assert.equal(r.final,null);assert.ok(!r.rows.find(x=>x.line==="43500"));
});
test("compare: context and contradictory final lines block numeric outcome",()=>{
assert.equal(E.compare(doc(),doc(),{}).final,null);
const b=doc();b["48400"].amount=1;assert.equal(E.compare(doc(),b,{sameContext:true}).final,null);
});
test("simulation: two federal credit claims flow through Quebec federal abatement",()=>{
const r=E.simulate(doc(),[edit("31800","1000"),edit("31900","200")],ctx);
assert.deepEqual(r.issues,[]);assert.equal(r.final.after,251304);assert.equal(r.final.change,14529);
assert.equal(r.rows.find(x=>x.line==="33500").after,2120000);
assert.equal(r.rows.find(x=>x.line==="35000").after,307400);
assert.equal(r.rows.find(x=>x.line==="42000").after,417600);
assert.match(r.province,/provincial income tax is separate/);
});
test("simulation: non-refundable credits cannot make basic tax negative",()=>{
const d=doc();d["40400"].amount=300000;d["42900"].amount=10000;d["42000"].amount=10000;d["43500"].amount=10000;d["44000"].amount=1650;d["48200"].amount=601650;d["48400"].amount=591650;
const r=E.simulate(d,[edit("31800","1000")],ctx);
assert.ok(r.final);assert.equal(r.rows.find(x=>x.line==="42000").after,0);assert.equal(r.final.change,8350);
});
test("simulation: payment changes cross from owing to refund",()=>{
const d=doc({"43700":1000,"47600":0,"43500":1500,"48200":1000,"48400":0,"48500":500});
const r=E.simulate(d,[edit("43700","1700"),edit("47600","100")],ctx);
assert.equal(r.final.before,-50000);assert.equal(r.final.after,30000);assert.equal(r.final.change,80000);
});
test("simulation: missing original line is not inferred zero",()=>{
const d=doc();delete d["31800"];
const r=E.simulate(d,[edit("31800","1000")],ctx);assert.equal(r.final,null);assert.ok(r.missing.includes("31800"));
});
test("simulation: unconfirmed, unsupported year, non-resident and unverified sources stop calculations",()=>{
const d=doc();d["31800"].confirmed=false;
for(const c of [{...ctx,year:2024},{...ctx,province:"NONRES"},{...ctx,officialVerified:false},{...ctx,scopeConfirmed:false}]) {
const r=E.simulate(doc(),[edit("31800","1000")],c);assert.equal(r.final,null);assert.equal(r.rows.filter(x=>x.type==="calculated consequence").length,0);
}
assert.equal(E.simulate(d,[edit("31800","1000")],ctx).final,null);
});
test("simulation: arbitrary unmapped line explains the missing dependency",()=>{
const d=doc();d["77777"]={amount:10000,confirmed:true};
const r=E.simulate(d,[edit("77777","200"),edit("43700","6500")],ctx);
assert.equal(r.final,null);assert.ok(r.issues.some(x=>x.code==="dependency not yet mapped" && x.lines.includes("77777")));
});
test("simulation: raw medical expenses are not multiplied by a blanket rate",()=>{
const d=doc();d["33099"]={amount:10000,confirmed:true};
assert.equal(E.simulate(d,[edit("33099","1000")],ctx).final,null);
});
test("simulation: overlapping totals and duplicate edits cannot double count",()=>{
assert.equal(E.simulate(doc(),[edit("31800","1000"),edit("35000","3100")],ctx).final,null);
assert.equal(E.simulate(doc(),[edit("43700","6500"),edit("48200","7000")],ctx).final,null);
assert.equal(E.simulate(doc(),[edit("31800","1000"),edit("31800","2000")],ctx).final,null);
});
test("simulation: 2025 top-up threshold, special taxes and inconsistent base stop final estimates",()=>{
const d=doc();d["33500"].amount=5730000;d["33800"].amount=830850;d["35000"].amount=830850;
assert.equal(E.simulate(d,[edit("31800","1000")],ctx).final,null);
const d2=doc();d2["41500"].amount=100;
assert.equal(E.simulate(d2,[edit("31800","1000")],ctx).final,null);
const d3=doc();d3["33800"].amount=1;assert.equal(E.simulate(d3,[edit("31800","1000")],ctx).final,null);
});
test("simulation: provincial calculation is never automatically assumed",()=>{
const r=E.simulate(doc(),[edit("31800","1000")],{...ctx,province:"ON"});
assert.equal(r.final,null);assert.ok(r.issues.some(i=>i.lines.includes("42800")));
const accepted=E.simulate(doc(),[edit("31800","1000"),edit("42800","0")],{...ctx,province:"ON"});
assert.ok(accepted.final);
});
test("simulation: multiple deductions propagate income, but stop before unmapped credits/province",()=>{
const d=doc();for(const line of ["11300","11900","14600","20800","21200"])d[line]={amount:0,confirmed:true};
const r=E.simulate(d,[edit("20800","1000"),edit("21200","200")],ctx);
assert.equal(r.rows.find(x=>x.line==="23600").after,4880000);
assert.equal(r.rows.find(x=>x.line==="26000").after,4880000);
assert.equal(r.rows.find(x=>x.line==="federal_gross").after,707600);
assert.equal(r.final,null);
});
test("simulation: zero old benefit repayment does not prove zero revised repayment",()=>{
const d=doc();d["20800"]={amount:0,confirmed:true};d["11300"]={amount:100000,confirmed:true};d["11900"]={amount:0,confirmed:true};d["14600"]={amount:0,confirmed:true};
const r=E.simulate(d,[edit("20800","1000")],ctx);
assert.equal(r.final,null);assert.ok(!r.rows.some(x=>x.line==="23600"));
});
test("simulation: inconsistent deduction components cannot create a negative total",()=>{
const d=doc();d["20800"]={amount:100000,confirmed:true};
const r=E.simulate(d,[edit("20800","0")],ctx);
assert.equal(r.final,null);
assert.ok(!r.rows.some(x=>x.line==="23300" || x.line==="23400"));
assert.ok(r.issues.some(i=>i.lines.includes("23300")));
});
test("federal brackets use the official T1 rounded column bases",()=>{
assert.equal(E.federalGross(5737500,2025),831938);
assert.equal(E.federalGross(6000000,2025),885751);
assert.equal(E.federalGross(11475000,2025),2008126);
assert.equal(E.federalGross(17788200,2025),3649557);
assert.equal(E.federalGross(25341400,2025),5839985);
assert.equal(E.federalGross(5000000,2024),null);
});
function references(now=Date.now()){
return Object.fromEntries(Object.entries(O.sources).map(([id,s])=>[id,{id,ok:true,hash:s.hash,checkedAt:now,amended:"2026-06-18",currentTo:"2026-09-30",signals:true}]));
}
test("official sources: fresh matching forms and consolidated legislation are required",()=>{
const r=references();assert.equal(O.check(r,2025,"QC").verified,true);
r.t1.hash="changed";assert.equal(O.check(r,2025,"QC").verified,false);
});
test("official sources: unavailable, stale, future and changed law versions are rejected",()=>{
for(const change of [
r=>delete r.act,r=>r.t1.checkedAt-=86400001,r=>r.act.amended="2026-10-15",r=>r.topup.signals=false,r=>r.quebec.checkedAt+=100000
]){const r=references();change(r);assert.equal(O.check(r,2025,"QC").verified,false);}
assert.equal(O.check(references(),2026,"QC").verified,false);
});
test("simulation: all arithmetic remains integer cents",()=>{
for(let cents=1;cents<100;cents++){
const r=E.simulate(doc(),[{line:"43700",amount:600000+cents}],ctx);
assert.equal(r.final.change,cents);assert.ok(Number.isSafeInteger(r.final.after));
}
});
